/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.common.DataSourceManager;

/**
 * @author pardec2
 * @version $Id$
 */
public class IssueHistoryConverter extends BasicConverter
{
    private static final String SOURCE_SQL = "select * from bug_history where field_name = 'details' order by bug_id, date";
    private static final String TARGET_SQL = "insert into issuehistorybean (id,description,status,create_date,last_modified,issue_id,user_id) values (?,?,?,?,?,?,?)";
    private static final String LAST_ID_SQL = "select max(id) from issuehistorybean";

    private int historyId = 0;
    
    private Logger log = Logger.getLogger(IssueHistoryConverter.class);
    
    protected String getSourceQuery()
    {
        return SOURCE_SQL;
    }
    
    protected String getTargetQuery()
    {
        return TARGET_SQL;
    }

    protected String getIdStoreName()
    {
        return "issuehistory";
    }

    protected String getLastIdQuery()
    {
        return LAST_ID_SQL;
    }

    protected int prepareTargetStatement(PreparedStatement targetStmt, ResultSet rs) throws Exception
    {
        int col = 1;
        targetStmt.setInt(col++, historyId++);
        targetStmt.setString(col++, rs.getString("old_value"));
        targetStmt.setInt(col++, 1);
        targetStmt.setTimestamp(col++, getDate(rs,"date"));
        targetStmt.setTimestamp(col++, getDate(rs,"date"));
        targetStmt.setInt(col++, rs.getInt("bug_id"));
        targetStmt.setInt(col++, rs.getInt("mod_by"));
        return BasicConverter.OK;
    }

    protected void additionalProcessing(PreparedStatement stmt, ResultSet rs)
        throws SQLException
    {
    }
    
    protected void preConversionProcessing()
    {
        log.info("Converting issue histories...");
        Object o = executeQuery(DataSourceManager.ITRACKER, "select max(id) from issuehistorybean");
        historyId = new Integer("" + o).intValue() + 1;
        log.info("History id " + historyId);
    }
    
    protected void postConversionProcessing()
    {
        log.info("Converted issue histories.");
    }
}
