/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.common.DataSourceManager;

/**
 * @author pardec2
 * @version $Id$
 */
public class ComponentConverter extends BasicConverter
{
    private static final String SOURCE_SQL = "select * from bug_category";
    private static final String TARGET_SQL = "insert into componentbean (id,name,description,status,create_date,last_modified, project_id) values (?,?,?,?,?,?,?)";
    private static final String LAST_ID_SQL = "select max(id) from componentbean";

    private Logger log = Logger.getLogger(ComponentConverter.class);
    
    protected String getSourceQuery()
    {
        return SOURCE_SQL;
    }
    
    protected String getTargetQuery()
    {
        return TARGET_SQL;
    }

    protected String getIdStoreName()
    {
        return "component";
    }
    
    protected String getLastIdQuery()
    {
        return LAST_ID_SQL;
    }

    protected int prepareTargetStatement(PreparedStatement targetStmt, ResultSet rs) throws Exception
    {
        long now = (new Date()).getTime();
        int col = 1;
        targetStmt.setObject(col++, rs.getObject("bug_category_id"));
        targetStmt.setObject(col++, rs.getObject("category_name"));
        targetStmt.setObject(col++, rs.getObject("category_name"));
        targetStmt.setInt(col++, 1);
        targetStmt.setTimestamp(col++, new Timestamp(now));
        targetStmt.setTimestamp(col++, new Timestamp(now));
        targetStmt.setInt(col++, rs.getInt("group_id"));
        return BasicConverter.OK;
    }

    protected void preConversionProcessing()
    {
        log.info( "Converting categories...");
        executeUpdate(DataSourceManager.ITRACKER, "delete from componentbean");
    }
}
