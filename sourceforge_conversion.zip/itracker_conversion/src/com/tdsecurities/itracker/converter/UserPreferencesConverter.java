/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.common.DataSourceManager;

/**
 * @author pardec2
 * @version $Id$
 */
public class UserPreferencesConverter extends BasicConverter
{
    private static final String SOURCE_SQL = "select * from user";
    private static final String LAST_ID_SQL = "select max(id) from userpreferencesbean";
    private static final String TARGET_SQL = "insert into userpreferencesbean (" 
            + " id,save_login,user_locale,num_items_index,num_items_issue_list,show_closed,"
            + " sort_column,hidden_index_sections,create_date,last_modified,user_id) values"
            + " (?,?,?,?,?,?,?,?,?,?,?)";

    private Logger log = Logger.getLogger(UserPreferencesConverter.class);
    
    private int prefsId = 1;
    
    protected String getSourceQuery()
    {
        return SOURCE_SQL;
    }
    
    protected String getTargetQuery()
    {
        return TARGET_SQL;
    }

    protected String getIdStoreName()
    {
        return "preferences";
    }

    protected String getLastIdQuery()
    {
        return LAST_ID_SQL;
    }

    protected int prepareTargetStatement(PreparedStatement targetStmt, ResultSet rs) throws Exception
    {
        long now = (new Date()).getTime();
        int col = 1;
        targetStmt.setInt(col++, prefsId++);
        targetStmt.setInt(col++, 0);
        targetStmt.setString(col++, "en_US");
        targetStmt.setInt(col++, -1);
        targetStmt.setInt(col++, -1);
        targetStmt.setInt(col++, 0);
        targetStmt.setString(col++, "sev");
        targetStmt.setInt(col++, 2);
        targetStmt.setTimestamp(col++, new Timestamp(now));
        targetStmt.setTimestamp(col++, new Timestamp(now));
        targetStmt.setInt(col++, rs.getInt("user_id"));
        return BasicConverter.OK;
    }

    protected void preConversionProcessing()
    {
        log.info( "Converting user preferences...");
        executeUpdate(DataSourceManager.ITRACKER, "delete from userpreferencesbean");
    }
}
