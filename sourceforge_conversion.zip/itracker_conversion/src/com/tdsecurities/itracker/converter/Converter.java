/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

/**
 * @author pardec2
 * @version $Id$
 */
public interface Converter
{
    public void convert();
}
