/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.common.DataSourceManager;

/**
 * @author pardec2
 * @version $Id$
 */
public class PermissionConverter extends BasicConverter
{
    private static final String SOURCE_SQL = "select * from user_group";
    private static final String TARGET_SQL = "insert into permissionbean (id,type,create_date,last_modified,project_id,user_id) values (?,?,?,?,?,?)";
    private static final String LAST_ID_SQL = "select max(id) from permissionbean";

    private Logger log = Logger.getLogger(PermissionConverter.class);
    private long id = 1;
    
    protected String getSourceQuery()
    {
        return SOURCE_SQL;
    }
    
    protected String getTargetQuery()
    {
        return TARGET_SQL;
    }

    protected String getIdStoreName()
    {
        return "permission";
    }

    protected String getLastIdQuery()
    {
        return LAST_ID_SQL;
    }

    protected int prepareTargetStatement(PreparedStatement targetStmt, ResultSet rs) throws Exception
    {
        return BasicConverter.SKIP_ROW;
    }

    protected void additionalProcessing(PreparedStatement targetStmt, ResultSet rs)
        throws SQLException
    {
        long now = (new Date()).getTime();
        int startPermission = 2;
        if( !"".equals(rs.getString("admin_flags")))
        {    
            startPermission = 1;
        }

        for( int i = startPermission; i <= 9; i++)
        {
            int col = 1;
            targetStmt.setLong(col++, id++);
            targetStmt.setInt(col++, i);
            targetStmt.setTimestamp(col++, new Timestamp(now));
            targetStmt.setTimestamp(col++, new Timestamp(now));
            targetStmt.setInt(col++, rs.getInt("group_id"));
            targetStmt.setInt(col++, rs.getInt("user_id"));
            targetStmt.executeUpdate();
        }
    }

    protected void preConversionProcessing()
    {
        log.info("Converting permissions ...");  
        executeUpdate(DataSourceManager.ITRACKER, "delete from permissionbean");
    }

    protected void postConversionProcessing()
    {
        log.info("Converted permissions.");  
    }
}
