/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.common.DataSourceManager;

/**
 * @author pardec2
 * @version $Id$
 */
public class VersionConverter extends BasicConverter
{
    private static final String SOURCE_SQL = "select distinct group_id from groups order by group_id";
    private static final String TARGET_SQL = "INSERT INTO versionbean (id,major,minor,version_number,description,status,create_date,last_modified,project_id) values (?, 1, 0, '1.0', '1.0', 1, ?, ?, ?)";
    private static final String LAST_ID_SQL = "select max(id) from versionbean";
    
    private Logger log = Logger.getLogger(VersionConverter.class);
    
    protected String getSourceQuery()
    {
        return SOURCE_SQL;
    }
    
    protected String getTargetQuery()
    {
        return TARGET_SQL;
    }

    protected String getIdStoreName()
    {
        return "version";
    }

    protected String getLastIdQuery()
    {
        return LAST_ID_SQL;
    }

    protected int prepareTargetStatement(PreparedStatement targetStmt, ResultSet rs) throws Exception
    {
        long now = (new Date()).getTime();
        int col = 1;
        targetStmt.setInt(col++, rs.getInt("group_id"));
        targetStmt.setTimestamp(col++, new Timestamp(now));
        targetStmt.setTimestamp(col++, new Timestamp(now));
        targetStmt.setInt(col++, rs.getInt("group_id"));
        return BasicConverter.OK;
    }

    protected void preConversionProcessing()
    {
        log.info("Creating versions");
        executeUpdate(DataSourceManager.ITRACKER, "delete from versionbean");
    }

    protected void postConversionProcessing()
    {
        log.info("Created versions");
    }
}
