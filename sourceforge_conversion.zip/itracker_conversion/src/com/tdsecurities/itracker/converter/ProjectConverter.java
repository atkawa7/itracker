/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.common.DataSourceManager;

/**
 * @author pardec2
 * @version $Id$
 */
public class ProjectConverter extends BasicConverter
{
    private static final String SOURCE_SQL = "select * from groups";
    private static final String TARGET_SQL = "insert into projectbean (id,name,description,status,options,custom_fields,create_date,last_modified) values (?,?,?,?,?,?,?,?)";
    private static final String LAST_ID_SQL = "select max(id) from projectbean";
    
    private Logger log = Logger.getLogger(ProjectConverter.class);
    
    protected String getSourceQuery()
    {
        return SOURCE_SQL;
    }
    
    protected String getTargetQuery()
    {
        return TARGET_SQL;
    }

    protected String getIdStoreName()
    {
        return "project";
    }

    protected String getLastIdQuery()
    {
        return LAST_ID_SQL;
    }

    protected int prepareTargetStatement(PreparedStatement targetStmt, ResultSet rs) throws Exception
    {
        long now = (new Date()).getTime();
        int col = 1;
        targetStmt.setObject(col++, rs.getObject("group_id"));
        targetStmt.setObject(col++, rs.getObject("group_name"));
        targetStmt.setObject(col++, rs.getObject("short_description"));
        targetStmt.setInt(col++, 1);
        targetStmt.setInt(col++, 6);
        targetStmt.setInt(col++, 0);
        targetStmt.setTimestamp(col++, getDate(rs,"register_time"));
        targetStmt.setTimestamp(col++, new Timestamp(now));
        return BasicConverter.OK;
    }

    protected void preConversionProcessing()
    {
        log.info( "Converting projects...");
        executeUpdate(DataSourceManager.ITRACKER, "delete from projectbean");
    }
}
