/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.common.DataSourceManager;

/**
 * @author pardec2
 * @version $Id$
 */
public class AttachmentConverter extends BasicConverter
{
    private static final String ATTACHMENTS_DIR = "/jboss-3.2.3/itracker/attachments/";
    private static final String SOURCE_SQL = "select a.bug_id, a.file_name, b.countorder, c.group_id, c.submitted_by, b.attachment from bug_attachment a, bug_split_attachment b, bug c where a.attachment_id = b.attachment_id and a.bug_id = c.bug_id";
    private static final String TARGET_SQL = "insert into issueattachmentbean (id,orig_file_name,type,file_name,description,file_size,create_date,last_modified,issue_id,user_id) values (?,?,?,?,?,?,?,?,?,?)";;
    private static final String LAST_ID_SQL = "select max(id) from issueattachmentbean";

    private int attachmentId = 1;
    private Logger log = Logger.getLogger(AttachmentConverter.class);
    
    protected String getSourceQuery()
    {
        return SOURCE_SQL;
    }
    
    protected String getTargetQuery()
    {
        return TARGET_SQL;
    }

    protected String getIdStoreName()
    {
        return "issueattachment";
    }
    
    protected String getLastIdQuery()
    {
        return LAST_ID_SQL;
    }

    protected int prepareTargetStatement(PreparedStatement targetStmt, ResultSet rs) throws Exception
    {
        long now = (new Date()).getTime();
        int col = 1;
        String filename = "proj" + rs.getInt("group_id") + 
                          "_issue" + rs.getInt("bug_id") +
                          "_attachment" + (rs.getInt("countorder") + 1);

        long size = writeFile( filename, rs.getBlob("attachment"));
        
        targetStmt.setInt(col++, attachmentId++);
        targetStmt.setString(col++, rs.getString("file_name"));
        targetStmt.setString(col++, "application/octet-stream");
        targetStmt.setString(col++, filename);
        targetStmt.setString(col++, rs.getString("file_name"));
        targetStmt.setLong(col++, size);
        targetStmt.setTimestamp(col++, new Timestamp(now));
        targetStmt.setTimestamp(col++, new Timestamp(now));
        targetStmt.setInt(col++, rs.getInt("bug_id"));
        targetStmt.setInt(col++, rs.getInt("submitted_by"));
        return BasicConverter.OK;
    }

    protected long writeFile(String filename, Blob data) throws Exception
    {
        BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(ATTACHMENTS_DIR + filename));
        InputStream in = null;
        long size;

        try
        {
            size = data.length();
            if (size > 0)
            {
                byte[] buff = new byte[1024];
                in = data.getBinaryStream();
                int i;
                while ((i = in.read(buff)) > 0)
                {
                    out.write(buff, 0, i);
                }
                out.flush();
            }
        }
        finally
        {
            if( in != null)
                in.close();
            if( out != null)
                out.close();
        }
        return size;
    }

    protected void preConversionProcessing()
    {
        log.info( "Converting attachments...");
        executeUpdate(DataSourceManager.ITRACKER, "delete from issueattachmentbean");
        File f = new File(ATTACHMENTS_DIR);
        File[] attachments = f.listFiles( new FilenameFilter()
        {
            public boolean accept(File dir, String name)
            {
                if(name.startsWith("proj"))
                    return true;
                return false;
            }
        });
        for (int i = 0; i < attachments.length; i++)
        {
            attachments[i].delete();
        }
    }
}
