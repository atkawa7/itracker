/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.common.DataSourceManager;

/**
 * @author pardec2
 * @version $Id$
 */
public abstract class BasicConverter implements Converter
{
    protected static final SimpleDateFormat SQL_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    protected static final int OK = 0;
    protected static final int SKIP_ROW = 1;
    protected DataSourceManager ds = DataSourceManager.getInstance();
    
    protected abstract String getSourceQuery();
    protected abstract String getTargetQuery();
    protected abstract String getIdStoreName();
    protected abstract String getLastIdQuery();
    protected abstract int prepareTargetStatement(PreparedStatement targetStmt, ResultSet rs) throws Exception;

    private Logger log = Logger.getLogger(BasicConverter.class);
    
    public final void convert()
    {
        PreparedStatement stmt = null;
        PreparedStatement targetStmt = null;
        ResultSet rs = null;
        
        Connection target = ds.getConnection(DataSourceManager.ITRACKER);
        Connection source = ds.getConnection(DataSourceManager.SOURCEFORGE);
        try
        {
            preConversionProcessing();
            stmt = source.prepareStatement(getSourceQuery());
            targetStmt = target.prepareStatement(getTargetQuery());
            log.debug( "Executing source query");
            rs = stmt.executeQuery();
            log.debug( "Processing results");
            while( rs.next())
            {
                log.debug( "Preparing update");
                if( prepareTargetStatement(targetStmt, rs) == OK)
                {    
                    log.debug( "Performing update");
                    targetStmt.executeUpdate();
                }
                additionalProcessing(targetStmt, rs);
            }
            postConversionProcessing();
            updateIdStore();
        }
        catch(Throwable t)
        {
            log.error("Processing failed: ", t);
            throw new RuntimeException("Error converting data", t);
        }
        finally
        {
            ds.cleanup(source, stmt, rs);
            ds.cleanup(target, targetStmt, null);
        }
    }
    
    protected void updateIdStore()
    {
        log.info( "Updating id store");
        PreparedStatement stmt = null;
        PreparedStatement updateStmt = null;
        ResultSet rs = null;
        
        Connection target = ds.getConnection(DataSourceManager.ITRACKER);
        try
        {
            stmt = target.prepareStatement(getLastIdQuery());
            rs = stmt.executeQuery();
            while( rs.next())
            {
                int lastId = rs.getInt(1);
                if( lastId > 0)
                {
                    executeUpdate(DataSourceManager.ITRACKER,
                        " update idstore set last_id = " + lastId + 
                        " where name = '" + getIdStoreName() + "'"
                    );
                }
            }
        }
        catch(Throwable t)
        {
            log.error("Processing failed updating id store: ", t);
        }
        finally
        {
            ds.cleanup(null, updateStmt, null);
            ds.cleanup(target, stmt, rs);
        }
    }

    protected void preConversionProcessing()
    {
    }

    protected void postConversionProcessing()
    {
    }
    
    protected void additionalProcessing(PreparedStatement stmt, ResultSet rs)
        throws SQLException
    {
    }
    
    protected void executeUpdate(String dataSourceName, String sql)
    {
        PreparedStatement stmt = null;
        
        Connection conn = ds.getConnection(dataSourceName);
        try
        {
            log.debug(sql);
            stmt = conn.prepareStatement(sql);
            int rows = stmt.executeUpdate();
            log.debug(rows + " affected");
        }
        catch(Throwable t)
        {
            log.error("Error executing '" + sql + "' on '" + dataSourceName +"'", t);
        }
        finally
        {
            ds.cleanup(conn, stmt, null);
        }
    }
    
    protected Object executeQuery(String dataSourceName, String sql)
    {
        Object o = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Connection conn = ds.getConnection(dataSourceName);
        try
        {
            log.debug(sql);
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            if( rs.next())
            {
                o = rs.getObject(1);
            }
        }
        catch(Throwable t)
        {
            log.error("Error executing '" + sql + "' on '" + dataSourceName +"'", t);
        }
        finally
        {
            ds.cleanup(conn, stmt, rs);
        }
        return o;
    }

    protected Timestamp getDate( ResultSet rs, String col)
        throws SQLException
    {
        long time = rs.getLong( col);
        time = time * 1000;
        return new Timestamp(time);
    }

    protected String getFormattedDate(ResultSet rs, String col)
        throws SQLException
    {
        Timestamp ts = getDate( rs, col);
        return SQL_DATE_FORMAT.format( ts);
    }
    
    protected String cleanString(String s)
    {
        String tmp = s.replaceAll("\\'","&quot;");
        tmp = tmp.replaceAll("\\\\","\\\\\\\\");
        return tmp;
    }
}
