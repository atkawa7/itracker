/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.common.DataSourceManager;

/**
 * @author pardec2
 * @version $Id$
 */
public class IssueConverter extends BasicConverter
{
    private static final String SOURCE_SQL = "select * from bug";
    private static final String TARGET_SQL = "insert into issuebean (id,severity,status,resolution,description,create_date,last_modified,target_version_id,creator_id,owner_id,project_id) values (?,?,?,?,?,?,?,?,?,?,?)";
    private static final String LAST_ID_SQL = "select max(id) from issuebean";

    private int historyId = 1;
    private Logger log = Logger.getLogger(IssueConverter.class);
    
    protected String getSourceQuery()
    {
        return SOURCE_SQL;
    }
    
    protected String getTargetQuery()
    {
        return TARGET_SQL;
    }

    protected String getIdStoreName()
    {
        return "issue";
    }

    protected String getLastIdQuery()
    {
        return LAST_ID_SQL;
    }

    protected int prepareTargetStatement(PreparedStatement targetStmt, ResultSet rs) throws Exception
    {
        long now = (new Date()).getTime();
        int col = 1;
        targetStmt.setInt(col++, rs.getInt("bug_id"));
        targetStmt.setInt(col++, getSeverity( rs.getInt("priority")));//severity
        targetStmt.setInt(col++, getStatus( rs));//status
        targetStmt.setString(col++, getResolution(rs.getInt("resolution_id")));
        targetStmt.setString(col++, rs.getString("summary"));
        targetStmt.setTimestamp(col++, getDate(rs,"date"));
        targetStmt.setTimestamp(col++, new Timestamp(now));
        targetStmt.setInt(col++, rs.getInt("group_id"));
        setInt(targetStmt, rs, col++, "submitted_by");
        setInt(targetStmt, rs, col++, "assigned_to");
        targetStmt.setInt(col++, rs.getInt("group_id"));
        return BasicConverter.OK;
    }
    
    protected void additionalProcessing(PreparedStatement stmt, ResultSet rs)
        throws SQLException
    {
        StringBuffer buf = new StringBuffer("insert into issue_component_rel ( issue_id, component_id) values (");
        buf.append(rs.getInt("bug_id")).append(",");
        buf.append(rs.getInt("category_id")).append(")");
        if( rs.getInt("category_id") != 0)
        {    
            executeUpdate(DataSourceManager.ITRACKER, buf.toString());
        }

        buf = new StringBuffer("insert into issue_version_rel ( issue_id, version_id) values (");
        buf.append(rs.getInt("bug_id")).append(",");
        buf.append(rs.getInt("group_id")).append(")");
        executeUpdate(DataSourceManager.ITRACKER, buf.toString());

        buf = new StringBuffer("insert into issuehistorybean (id,description,status,create_date,last_modified,issue_id,user_id) values (");
        buf.append(historyId++).append(",'");
        buf.append(cleanString(rs.getString("details"))).append("',");
        buf.append(1).append(",'");
        buf.append(getFormattedDate(rs, "date")).append("','");
        buf.append(getFormattedDate(rs, "date")).append("',");
        buf.append(rs.getInt("bug_id")).append(",");
        buf.append(rs.getInt("submitted_by")).append(")");
        executeUpdate(DataSourceManager.ITRACKER, buf.toString());
    }

    protected void setInt(PreparedStatement stmt, ResultSet rs, int col, String key)
        throws SQLException
    {
        if( rs.getInt(key) == 0)
        {    
            stmt.setNull(col, Types.INTEGER);
        }
        else
        {
            stmt.setInt(col, rs.getInt(key));
        }
    }

    protected void preConversionProcessing()
    {
        log.info("Converting issues...");
        executeUpdate(DataSourceManager.ITRACKER, "delete from issuebean");
        executeUpdate(DataSourceManager.ITRACKER, "delete from issuehistorybean");
        executeUpdate(DataSourceManager.ITRACKER, "delete from issue_component_rel");
        executeUpdate(DataSourceManager.ITRACKER, "delete from issue_version_rel");
    }
    
    protected void postConversionProcessing()
    {
        log.info("Converted issues.");
    }

    protected int getSeverity(int priority)
    {
        int severity = 5;
        severity = 6 - (int)Math.ceil( (float)priority/2f);
        return severity;
    }
    
    protected int getStatus(ResultSet rs)
        throws SQLException
    {
        int status = rs.getInt("status_id");
        int newStatus = 0;
        switch(status)
        {
            case 1:   newStatus = 100; break;
            case 3:   newStatus = 500; break;
            case 100: newStatus = 100; break;
            case 101: newStatus = 300; break;
            case 102: newStatus = 330; break;
            case 105: newStatus = 320; break;
            case 106: newStatus = 340; break;
            default:  newStatus = 100; break;
        }
        if( newStatus == 100)
        {
            int owner = rs.getInt("assigned_to");
            if( owner != 0 && !rs.wasNull())
            {
                newStatus = 300;
            }
        }
        return newStatus;
    }
    
    protected String getResolution(int resolution)
    {
        switch(resolution)
        {
            case 1:   return "Fixed";//Fixed
            case 2:   return "Invalid";//Invalid
            case 3:   return "Won't fix";//Wont Fix
            case 4:   return "Postponed";//Later
            case 5:   return "Postponed";//Remind
            case 6:   return "Works for me";//Works For Me
            case 100: return "";//None
            case 101: return "Duplicate";//Duplicate
            default: return "";
        }
    }
}
