/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.converter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.common.DataSourceManager;
import com.tdsecurities.itracker.security.LdapAuthenticate;
import com.tdsecurities.itracker.security.LdapDistinguishedName;

/**
 * @author pardec2
 * @version $Id$
 */
public class UserConverter extends BasicConverter
{
    private static final String ADMIN = "admin";
    private static final String SOURCE_SQL = "select * from user";
    private static final String TARGET_SQL = "insert into userbean (id,login,password,first_name,last_name,email,status,registration_type,super_user,create_date,last_modified,preferences_id) values (?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String LAST_ID_SQL = "select max(id) from userbean";

    private Logger log = Logger.getLogger(UserConverter.class);
    
    protected String getSourceQuery()
    {
        return SOURCE_SQL;
    }
    
    protected String getTargetQuery()
    {
        return TARGET_SQL;
    }

    protected String getIdStoreName()
    {
        return "user";
    }

    protected String getLastIdQuery()
    {
        return LAST_ID_SQL;
    }

    protected int prepareTargetStatement(PreparedStatement targetStmt, ResultSet rs) throws Exception
    {
        String username = rs.getString("user_name");
        LdapAuthenticate ldap = new LdapAuthenticate();
        LdapDistinguishedName ldapName = ldap.getAttributesFromLoginId(username);

        if( ADMIN.equals(username))
        {
            log.info( "-> Skipped user " + username);
            return BasicConverter.SKIP_ROW;
        }
        
        String firstName, lastName, email;
        if( ldapName != null)
        {
            firstName = ldapName.getFirstName();
            lastName = ldapName.getLastName();
            email = ldapName.getEmail();
        }
        else
        {
            log.info( "-> No LDAP entry for " + username);
            firstName = "";
            lastName = rs.getString("realname");
            email = rs.getString("email");
        }

        long now = (new Date()).getTime();
        int col = 1;
        targetStmt.setObject(col++, rs.getObject("user_id"));
        targetStmt.setObject(col++, username);
        targetStmt.setNull(col++, Types.VARCHAR);
        targetStmt.setObject(col++, firstName);
        targetStmt.setObject(col++, lastName);
        targetStmt.setObject(col++, email.toLowerCase());
        targetStmt.setInt(col++, 1);
        targetStmt.setInt(col++, 1);
        targetStmt.setInt(col++, 0);
        targetStmt.setTimestamp(col++, getDate(rs, "add_date"));
        targetStmt.setTimestamp(col++, new Timestamp(now));
        targetStmt.setNull(col++, Types.VARCHAR);
        return BasicConverter.OK;
    }

    protected void preConversionProcessing()
    {
        log.info( "Converting users...");
        executeUpdate(DataSourceManager.ITRACKER, "update userbean set id = 1 where login = 'admin'");
        executeUpdate(DataSourceManager.ITRACKER, "delete from userbean where login <> 'admin'");
    }
}
