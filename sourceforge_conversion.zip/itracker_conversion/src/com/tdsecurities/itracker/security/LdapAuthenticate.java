package com.tdsecurities.itracker.security;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

/**
 */
public class LdapAuthenticate
{
	public static final int LOGIN_SUCCESS = 0;
	public static final int USER_NOT_EXIST = 1;
	public static final int WRONG_PASSWORD = 2;
	public static final int UNKNOWN_ERROR = 3;
	
    // LDAP servers
    public static final String [] PROVIDER_URL = 
    {
        "ldap://ldap1.com:389",
        "ldap://ldap2.com:389",
        "ldap://ldap3.com:389",
        "ldap://ldap4.com:389",
    };
    // Search LDAP server for how many times
    private static final int CYCLE = 2;
    // Should we print out debug message
    private static final boolean DEBUG = false;
    
    // basic LDAP search information
    public static String SECURITY_PRINCIPAL = "";
    public static String SECURITY_CREDENTIALS = "";
    public static String SEARCH_DOMAIN = "";
    
    // The active server id
    private int active = 0;
    private DirContext dirctx = null;
    private DirContext ctx = null;
    
    /**
     * Constructor, used to create assign the value for 
     * PRINCIPAL, CREDENTIAL and SEARCH_DOMAIN information
     */
    public LdapAuthenticate()
    {
    	// We can read these credential information from a properties file
        SECURITY_PRINCIPAL = "cn=svc,ou=serviceaccounts,ou=bc,dc=corp,dc=acme,dc=com";
        SECURITY_CREDENTIALS = "cred";
        SEARCH_DOMAIN = "dc=corp,dc=acme,dc=com";
    }

	/**
	 * Go through all the LDAP server to login
	 */
    private void initDirContext() 
    	throws NamingException
    {
        // number of cycle for round robin
        for (int j = 0; j < CYCLE; j++)
        {
            // round robin
            for (int i = 0; i < PROVIDER_URL.length; i++)
            {
                active = i;
                try 
                {
                    log ("Trying LDAP Server: " + PROVIDER_URL[active] + " ...");
                    dirctx = getDirContext(
                    	PROVIDER_URL[active], SECURITY_PRINCIPAL, SECURITY_CREDENTIALS);
                    log ("Successfully connected to LDAP Server: " + PROVIDER_URL[active]);
                    return;
                } 
                catch( NamingException e ) 
                {
                    log ("Failed to connect to LDAP Server #" + i + ": " + PROVIDER_URL[active]);
                    log ("Reason:" + e);
                    closeDirContext();
                }
            }
        }
        log ("None of the LDAP server can be connected.");
        throw new NamingException(
        	"None of the LDAP server can be connected");
    }

	/**
	 * Close the all the directory context
	 * Do not throw exception from here
	 */
    private void closeDirContext()
    {
        try 
        {
            if (dirctx != null) 
            {
                dirctx.close();
            }
            if (ctx != null) 
            {
                ctx.close();
            }
        } 
        catch(NamingException e)
        {
            log("Could not close the connection to LDAP server - " +  e );
        }
    }
    
    /**
     * This method gets an active directory context
     *
     * @param ldap_url  URL to connect to LDAP server
     * @param login  LDAP login ID
     * @param password  LDAP Password
     */
    private DirContext getDirContext(
    	String ldap_url, String login, String passwd) 
    	throws NamingException 
    {
        // connect to active directory
        Hashtable env = new Hashtable();
        env.put( Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put( Context.SECURITY_AUTHENTICATION, "simple");
        env.put( "com.sun.indi.ldap.trace.ber", System.err );

        env.put( Context.PROVIDER_URL, ldap_url);
        env.put( Context.SECURITY_PRINCIPAL, login);
        env.put( Context.SECURITY_CREDENTIALS, passwd);

        return new InitialDirContext( env );
    }

    /**
     * This method provides a functionality to authenticate a Login/Password combination, using
     * LDAP Server.
     *
     * @param login  Login ID to be authenticated
     * @param password Login ID to be authenticated
     */
    public int doAuthentication(String login, String password)
        throws NamingException
    {
        int result = UNKNOWN_ERROR;
        log ("Start searching for user " + login);

        try 
        {
			initDirContext();
            SearchControls searchControls = new SearchControls();
            searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            // Search for objects using the filter
            NamingEnumeration answer = dirctx.search(
            	SEARCH_DOMAIN, "(&(sAMAccountName=" + login + "))", searchControls);

            if (answer.hasMore()) 
            {
                SearchResult searchResult = (SearchResult)answer.next();
                String userName = searchResult.getName();
                log("User found : " + userName);
                ctx = getDirContext(
                    	PROVIDER_URL[active], userName + "," + SEARCH_DOMAIN, password);
                result = LOGIN_SUCCESS;
            } 
            else 
            {
                log("User NOT found.");
                result = USER_NOT_EXIST;
            }
        }
        catch( AuthenticationException e ) 
        {
            log("Invalid password. Logon failed." );
            result = WRONG_PASSWORD;
        }
        finally
        {
            closeDirContext();
        }
        return result;
    }

    public LdapDistinguishedName getAttributesFromLoginId(String login)
        throws NamingException
    {
        LdapDistinguishedName ldapName = null;

        if (login == null)
        {
            return null;
        }

        try
        {
            initDirContext();
            SearchControls ctls = new SearchControls();
            ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);

            // Search for objects using the filter
            NamingEnumeration answer =
                dirctx.search(SEARCH_DOMAIN, "(&(sAMAccountName=" + login + "))", ctls);

            if(answer.hasMore())
            {
                SearchResult searchResult = (SearchResult) answer.next();
                ldapName = new LdapDistinguishedName(searchResult.getAttributes());
                log(ldapName.toString());
            }
        }
        finally
        {
            closeDirContext();
        }
        return ldapName;
    }

    /**
	 * Keep the log of the LDAP authentication
	 */
    protected void log (String s)
    {
    	if (DEBUG)
    	{
        	System.out.println("<LDAPAuthenticate> - " + s);
    	}
    }
}
