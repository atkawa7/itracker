package com.tdsecurities.itracker.security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Use MD5 to encryt the input data
 */
public class EncryptData
{
	
	private static String ENCRYPT_TYPE_MD = "MD5";
	
	/**
	 * Method uses the md5 digester to create the Encrypted data
	 * @return _encryptData java.lang.String(16 bytes - length 48)
	 * @param _cleardata    java.lang.String
	 */
	public static String md5(String _cleardata)
	{
		String _encryptData = null;
		{
//			System.out.println("EncryptData.md5(" + _cleardata + ")");
			try
			{
				//Getting  the md5 digester
				MessageDigest _messageDigest = 
					MessageDigest.getInstance(ENCRYPT_TYPE_MD);
	
				//Resetting  the digester
				_messageDigest.reset();
	
	
				//processing the data
				_messageDigest.update(_cleardata.getBytes());
	
				//Getting  the digested data
				byte[] _digestedData = _messageDigest.digest();
				StringBuffer _strBuffer = new StringBuffer();
				for (int _i = 0; _i < _digestedData.length; _i++)
				{
					_strBuffer.append(Integer.toHexString(0xFF & _digestedData[_i]));
					_strBuffer.append(" ");
				}
				_encryptData = _strBuffer.toString();
			}
			catch (NoSuchAlgorithmException _nosuchalgorithmException)
			{
				System.out.println(
					"EncryptData:md5 Failed to get cryptographic algorithm" 
					+ _nosuchalgorithmException);
			}
			catch (NullPointerException _nullpointerException)
			{
				System.out.println(
					"EncryptData:md5: NullPointerException while encrypting data." 
					+ _nullpointerException);
			}
		}
		return _encryptData;
	}
	
	
	public static void main(String[] args)
	{
		String password = "pass004";
		String encrypted = EncryptData.md5(password);
		System.out.println(encrypted);
	}

}
