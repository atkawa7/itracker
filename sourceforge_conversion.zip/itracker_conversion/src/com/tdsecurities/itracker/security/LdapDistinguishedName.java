package com.tdsecurities.itracker.security;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import org.apache.log4j.Logger;

public class LdapDistinguishedName
{
    protected Logger log = Logger.getLogger(LdapDistinguishedName.class);
    private Attributes attributes = null;
	private String commonName = null;
	private String userName = null;
	private String firstName = null;
    private String lastName = null;
    private String email = null;

    public LdapDistinguishedName(Attributes _attributes)
        throws NamingException
    {
        attributes = _attributes;
        commonName = getAttribute("distinguishedName");
        firstName = getAttribute("givenName");
        lastName = getAttribute("sn");
        email = getAttribute("mail");
    }
    
    protected String getAttribute(String key) throws NamingException
    {
        String value = "";
        Attribute attr = attributes.get(key);
        if( attr != null)
        {    
            Object o = attr.get(0);
            if( o != null)
            {    
                value = o.toString();
            }
        }
        return value;
    }

	/**
	 * Method getFirstName.
	 * @return String
	 */
	public String getFirstName()
	{
		return firstName;
	}
	
	/**
	 * Method getLastName.
	 * @return String
	 */
	public String getLastName()
	{
		return lastName;
	}
	
	/**
	 * Method getCommonName.
	 * @return String
	 */
	public String getCommonName()
	{
		return commonName;
	}

	/**
	 * Method getUserName.
	 * @return String
	 */
	public String getUserName()
	{
		return userName;
	}

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getEmail()
    {
        return email;
    }
}
