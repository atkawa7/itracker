/**
 * Copyright (c) 2003 TD Securities
 * Created on Dec 31, 2003
 */
package com.tdsecurities.itracker.servlet;

import java.io.IOException;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.tdsecurities.itracker.converter.Converter;

/**
 * @author pardec2
 * @version $Id$
 */
public class ConversionServlet extends HttpServlet
{
    private static final String SESSION_MSG = "msg";
    private Logger log = Logger.getLogger(ConversionServlet.class);
    private static final String CONVERTER_LIST_PARAM = "ConverterList";
    private static final String DELIM = ",";

    protected void forward(HttpServletRequest request, HttpServletResponse response, String destinationPage)
        throws IOException, ServletException
    {
        RequestDispatcher dispatcher = request.getRequestDispatcher(destinationPage);
        dispatcher.forward(request, response);
    }   

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        HttpSession session = request.getSession();
        session.setAttribute(SESSION_MSG,"");
        log.info("Post request received");
        String converters = getServletContext().getInitParameter(CONVERTER_LIST_PARAM);
        StringTokenizer tokenizer = new StringTokenizer(converters, DELIM);
        Converter converter = null;
        while( tokenizer.hasMoreTokens())
        {    
            String token = tokenizer.nextToken();
            token = token.trim();
            try
            {
                converter = (Converter)Class.forName("com.tdsecurities.itracker.converter." + token).newInstance();
                converter.convert();
            }
            catch(Throwable t)
            {
                String msg = (String)session.getAttribute(SESSION_MSG);
                String msg2 =  "Error running converter " + token + ": " + t.toString();
                session.setAttribute(SESSION_MSG, msg + "<BR/>" + msg2);
                log.error(msg2, t);
                continue;
            }
        }
        log.info( "Conversion complete.");
        String msg = (String)session.getAttribute(SESSION_MSG); 
        if( msg == null || msg.length() <= 0)
            session.setAttribute(SESSION_MSG, "Lookin' good!");

        forward(request, response, "/index.jsp");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        log.info("Get request received");
    }
}
