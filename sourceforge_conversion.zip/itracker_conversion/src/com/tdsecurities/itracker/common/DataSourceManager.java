package com.tdsecurities.itracker.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

/**
 */
public class DataSourceManager
{
	protected final Logger log = Logger.getLogger(DataSourceManager.class);

    public static final String ITRACKER = "java:/ITrackerDS";
    public static final String SOURCEFORGE = "java:/SourceForgeDS";

    private Hashtable sources = new Hashtable();
	private static DataSourceManager singletion;

	static {
		singletion = new DataSourceManager();
	}

	static public DataSourceManager getInstance()
	{
		return singletion;
	}

	private DataSourceManager()
	{
		try
		{
			Context context = new InitialContext();
            sources.put( ITRACKER, context.lookup(ITRACKER));
            sources.put( SOURCEFORGE, context.lookup(SOURCEFORGE));
		}
		catch (NamingException ne)
		{
			log.error(
				"NamingException caught while trying to instantiate DataSourceManager.",
				ne);
			throw new Error(ne);
		}
	}

	public Connection getConnection(String dataSourceName)
	{
		Connection conn = null;
		try
		{
            DataSource ds = (DataSource) sources.get(dataSourceName);
			conn = ds.getConnection();
		}
		catch (Throwable t)
		{
			log.error("Cannot establish a database connection to " + dataSourceName, t);
		}
		return conn;
	}

	public void cleanup(
		Connection connection,
		Statement statement,
		ResultSet resultSet)
	{
		closeResultSet(resultSet);
		if (statement != null)
		{
			try
			{
				statement.close();
			}
			catch (Exception e)
			{
				log.warn("Problem closing Statement object.", e);
			}
		}
		statement = null;
		closeConnection(connection);
	}

	private void closeResultSet(ResultSet resultSet)
	{
		if (resultSet != null)
		{
			try
			{
				resultSet.close();
			}
			catch (Exception e)
			{
				log.warn("Problem closing ResultSet object.", e);
			}
		}
		resultSet = null;
	}

	private void closeConnection(Connection connection)
	{
		if (connection != null)
		{
			try
			{
				connection.close();
			}
			catch (Exception e)
			{
				log.warn("Problem closing Connection object.", e);
			}
		}
		connection = null;
	}
}
