
Conversion utility
==================

This conversion utility was written to convert a SourceForge database into an ITracker database.  It doesn't convert everything but it does do most things including:
- Projects
- Users
- Components
- Issues
- Issue History
- Attachments
- Permissions
- Preferences
- Versions

Some of the conversions are quite liberal in their interpretation.  The main point of the exercise was to convert as much *useful* data in as short a period of time as possible.

I spent less than two days writing this so please excuse the rough edges.

Database Connections
====================

Use the *-ds.xml files in the conf directory as a guideline on how to configure the datasources for the conversion.


Noteworthy
==========

This was written specifically for our installation and therefore has a few things that you may need to change.

1. It has only been tested on JBoss 3.2.2.
2. It uses an LDAP server for the user info
3. There is a fair amount of hard-coding that you may need to modify.
4. For the attachments to work, you'll probably need to crank up the available memory to 256Mb or 512Mb in JBoss.

Regards,
Craig Pardey

PS - please send thanks and praise to craigpardey@hotmail.com
